<?php $__env->startSection('title', 'User Edit'); ?>
<?php $__env->startSection('container'); ?>
    <div class="container">

        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Dashboard</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin_user_list')); ?>">Users</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">User Edit</a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="card mx-4">
            <div class="card-header">
                <h5><a href="<?php echo e(route('admin_user_list')); ?>"><i class="fas fa-arrow-alt-circle-left"
                            title="Back To User List"></i></a> User Edit</h5>
            </div>
            <div class="card-body">

                <?php echo $__env->make('status', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <div class="editFormDiv">
                    <h5><u>Update Personal Details : </u></h5>
                    <form action="<?php echo e(route('admin_user_update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="user_id" id="user_id" value="<?php echo e($user->uuid); ?>">
                        <div class="row">
                            <div class="col-md-3 form-group">
                                <label for="name">Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" id="name" class="form-control"
                                    value="<?php echo e($user->name); ?>" placeholder="Enter Name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-3 form-group">
                                <label for="email">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" id="email" class="form-control"
                                    value="<?php echo e($user->email); ?>" placeholder="Enter Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-3 form-group">
                                <label for="mobile_no">Mobile <span class="text-danger">*</span></label>
                                <input type="text" name="mobile_no" id="mobile_no" class="form-control"
                                    value="<?php echo e($user->mobile_no); ?>" placeholder="Enter Mobile Number">
                                <?php $__errorArgs = ['mobile_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                        </div>

                        <div class="sb_btn text-end">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>

                <hr>

                <div class="btns">
                    <h5><u>Update Status & KYC Details : </u></h5>
                    <div class="row text-center">

                        <div class="col-md-2 form-group">
                            <label for="">User Status</label><br>
                            <input type="checkbox" <?php echo e($user->user_status == 'active' ? 'checked' : ''); ?>

                                data-toggle="toggle" data-width="100" data-height="75" data-onlabel="Active"
                                data-offlabel="Block" data-onstyle="success" data-offstyle="danger" data-type="user_status">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">User BAN</label><br>
                            <input type="checkbox" <?php echo e($user->user_status == 'ban' ? 'checked' : ''); ?> data-toggle="toggle"
                                data-width="100" data-height="75" data-onlabel="BAN" data-offlabel="Not BAN"
                                data-onstyle="success" data-offstyle="danger" data-type="user_ban">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">Email Verification</label><br>
                            <input type="checkbox" <?php echo e($user->email_verified_at != null ? 'checked' : ''); ?>

                                data-toggle="toggle" data-width="100" data-height="75" data-onlabel="Verified"
                                data-offlabel="Not Verify" data-onstyle="success" data-offstyle="danger"
                                data-type="email_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">Mobile Verification</label><br>
                            <input type="checkbox" <?php echo e($user->mobile_verified_at != null ? 'checked' : ''); ?>

                                data-toggle="toggle" data-width="100" data-height="75" data-onlabel="Verified"
                                data-offlabel="Not Verify" data-onstyle="success" data-offstyle="danger"
                                data-type="mobile_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">Aadhar Verification</label><br>
                            <input type="checkbox" <?php echo e($user->aadhar_verified != 0 ? 'checked' : ''); ?>

                                data-toggle="toggle" data-width="100" data-height="75" data-onlabel="Verified"
                                data-offlabel="Not Verify" data-onstyle="success" data-offstyle="danger"
                                data-type="aadhar_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">PAN Verification</label><br>
                            <input type="checkbox" <?php echo e($user->pan_verified != 0 ? 'checked' : ''); ?> data-toggle="toggle"
                                data-width="100" data-height="75" data-onlabel="Verified" data-offlabel="Not Verify"
                                data-onstyle="success" data-offstyle="danger" data-type="pan_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">Bank Verification</label><br>
                            <input type="checkbox" <?php echo e($user->bank_verified != 0 ? 'checked' : ''); ?> data-toggle="toggle"
                                data-width="100" data-height="75" data-onlabel="Verified" data-offlabel="Not Verify"
                                data-onstyle="success" data-offstyle="danger" data-type="bank_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">VPA Verification</label><br>
                            <input type="checkbox" <?php echo e($user->vpa_verified != 0 ? 'checked' : ''); ?> data-toggle="toggle"
                                data-width="100" data-height="75" data-onlabel="Verified" data-offlabel="Not Verify"
                                data-onstyle="success" data-offstyle="danger" data-type="vpa_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">KYC Verification</label><br>
                            <input type="checkbox" <?php echo e($user->kyc_verified != 0 ? 'checked' : ''); ?> data-toggle="toggle"
                                data-width="100" data-height="75" data-onlabel="Verified" data-offlabel="Not Verify"
                                data-onstyle="success" data-offstyle="danger" data-type="kyc_verify">
                        </div>

                        <div class="col-md-2 form-group">
                            <label for="">2FA Enable</label><br>
                            <input type="checkbox" <?php echo e($user->google2fa_enable == 'yes' ? 'checked' : ''); ?>

                                data-toggle="toggle" data-width="100" data-height="75" data-onlabel="Enable"
                                data-offlabel="Disable" data-onstyle="success" data-offstyle="danger" data-type="2fa">
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready(function() {
            // Attach event listener to elements with data-toggle="toggle"
            $('input[type="checkbox"]').change(function() {
                let type = $(this).data('type');
                updateStatus(this, type);
            });

            // Initialize toggle buttons if needed
            // $('[data-toggle="toggle"]').bootstrapToggle();
        });

        function updateStatus(input, type, other = null) {
            let inputData = $(this)
            let user_id = $('#user_id').val()
            $.ajax({
                type: "post",
                url: "<?php echo e(route('admin_user_status_update')); ?>",
                data: {
                    "status_type": type,
                    "user_id": user_id,
                    "_token": "<?php echo e(csrf_token()); ?>"
                },
                success: function(response) {
                    console.log(response);
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\CreatedInAm\MetaMarketAdmin\resources\views/users/edit.blade.php ENDPATH**/ ?>