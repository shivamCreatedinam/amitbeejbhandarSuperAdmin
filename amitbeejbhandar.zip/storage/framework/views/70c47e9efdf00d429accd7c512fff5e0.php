<footer class="footer">
    <div class="container-fluid d-flex justify-content-between">
      <nav class="pull-left">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="#">
                Createdinam 
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#"> Help </a>
          </li>

        </ul>
      </nav>
      <div class="copyright">
        2024, made with <i class="fa fa-heart heart text-danger"></i> by
        <a href="#">Createdinam </a>
      </div>
      <div>
        Distributed by
        <a target="_blank" href="#">Createdinam</a>.
      </div>
    </div>
  </footer>
<?php /**PATH D:\xampp\htdocs\CreatedInAm\amitbeejbhandar\resources\views/partials/footer.blade.php ENDPATH**/ ?>