<?php $__env->startSection('title', 'User View'); ?>
<?php $__env->startSection('container'); ?>
    <div class="container">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Dashboard</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo e(route('dashboard')); ?>">
                            <i class="icon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin_user_list')); ?>">Users</a>
                    </li>
                    <li class="separator">
                        <i class="icon-arrow-right"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">User View</a>
                    </li>
                </ul>
            </div>
        </div>

        <div class="card mx-4">
            <div class="card-header">
                <h5><a href="<?php echo e(route('admin_user_list')); ?>"><i class="fas fa-arrow-alt-circle-left"
                            title="Back To User List"></i></a> User Status : <?php if($user->user_status === 'active'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php elseif($user->user_status === 'block' || $user->user_status === 'ban'): ?>
                        <span class="badge bg-danger"><?php echo e(ucfirst($user->user_status)); ?></span>
                    <?php endif; ?>
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h4>1. Personal Details</h4>
                        <table class="table table-hover">
                            <tr>
                                <th>Full Name :</th>
                                <td><?php echo e($user->name); ?></td>
                            </tr>
                            <tr>
                                <th>Email :</th>
                                <td><a href="mailto:<?php echo e($user->email); ?>"
                                        style="text-decorations:none; color:inherit;"><?php echo e($user->email); ?></a></td>
                            </tr>
                            <tr>
                                <th>Mobile :</th>
                                <td><a href="tel:<?php echo e($user->mobile_no); ?>"
                                        style="text-decorations:none; color:inherit;"><?php echo e($user->mobile_no); ?></a></td>
                            </tr>

                            <tr>
                                <th>2FA Verification :</th>
                                <td><?php echo $user->google2fa_enable != 'no'
                                    ? "<span class='badge bg-success'>Enable</span>"
                                    : "<span class='badge bg-danger'>Disabled</span>"; ?></td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h4>2. KYC Details</h4>
                        <table class="table table-hover">
                            <tr>
                                <th>Email Verification :</th>
                                <td><?php echo $user->email_verified_at != null
                                    ? "<span class='badge bg-success'>Verified</span>"
                                    : "<span class='badge bg-danger'>Not Verified</span>"; ?></td>
                            </tr>
                            <tr>
                                <th>Mobile Verification :</th>
                                <td><?php echo $user->mobile_verified_at != null
                                    ? "<span class='badge bg-success'>Verified</span>"
                                    : "<span class='badge bg-danger'>Not Verified</span>"; ?></td>
                            </tr>
                            <tr>
                                <th>Aadhar Verification :</th>
                                <td>
                                    <?php if($user->aadhar_verified != 0): ?>
                                        <span class="badge bg-success">Verified</span> |
                                        <a class="badge bg-warning" href="<?php echo e(asset('public/assets/img/arashmil.jpg')); ?>"
                                            target="_blank">View</a>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Verified</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>PAN Verification :</th>
                                <td>
                                    <?php if($user->pan_verified != 0): ?>
                                        <span class="badge bg-success">Verified</span> |
                                        <a class="badge bg-warning" href="<?php echo e(asset('public/assets/img/arashmil.jpg')); ?>"
                                            target="_blank">View</a>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Verified</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>Bank Verification :</th>
                                <td>
                                    <?php if($user->bank_verified != 0): ?>
                                        <span class="badge bg-success">Verified</span> |
                                        <a class="badge bg-warning" href="<?php echo e(asset('public/assets/img/arashmil.jpg')); ?>"
                                            target="_blank">View</a>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Verified</span>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <tr>
                                <th>VPA Verification :</th>
                                <td>
                                    <?php if($user->vpa_verified != 0): ?>
                                        <span class="badge bg-success">Verified</span> |
                                        <a class="badge bg-warning" href="<?php echo e(asset('public/assets/img/arashmil.jpg')); ?>"
                                            target="_blank">View</a>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Verified</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th>KYC Verification :</th>
                                <td>
                                    <?php if($user->kyc_verified != 0): ?>
                                        <span class="badge bg-success">Verified</span> |
                                        <a class="badge bg-warning" href="<?php echo e(asset('public/assets/img/arashmil.jpg')); ?>"
                                            target="_blank">View</a>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Not Verified</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\CreatedInAm\MetaMarketAdmin\resources\views/users/view.blade.php ENDPATH**/ ?>