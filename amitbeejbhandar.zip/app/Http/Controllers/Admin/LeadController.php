<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Lead;
use Illuminate\Http\Request;

class LeadController extends Controller
{
    public function index(Request $request)
    {
        if ($request->ajax()) {

            // Page Length
            $pageNumber = ($request->start / $request->length) + 1;
            $pageLength = $request->length;
            $skip = ($pageNumber - 1) * $pageLength;
            $search = $request->search['value'];
            // $order = $request->order[0]['column'];
            $dir = $request->order[0]['dir'];
            // $column = $request->columns[$order]['data'];

            $leads = Lead::query()->orderBy('created_at', $dir);

            if ($search) {
                $leads->where(function ($q) use ($search) {
                    $q->orWhere('name', 'like', '%' . $search . '%');
                    $q->orWhere('email', 'like', '%' . $search . '%');
                    $q->orWhere('mobile', 'like', '%' . $search . '%');
                    $q->orWhere('gst_number', 'like', '%' . $search . '%');
                });
            }
            $total = $leads->count();
            $leads = $leads->skip($skip)->take($pageLength)->get();
            $return = [];
            foreach ($leads as $key => $lead) {

                // fetch trade status
                $return[] = [
                    'id' => $key + 1,
                    'name' => $lead->name,
                    'email' => $lead->email,
                    'mobile' => $lead->mobile,
                    'quotes' => $lead->quotes,
                    'gst_number' => $lead->gst_number,
                    'remarks' => $lead->remarks,
                    'actions' => "-",
                ];
            }
            return response()->json([
                'draw' => $request->draw,
                'recordsTotal' => $total,
                'recordsFiltered' => $total,
                'data' => $return,
            ]);
        }
        return view('leads.index');
    }
}
